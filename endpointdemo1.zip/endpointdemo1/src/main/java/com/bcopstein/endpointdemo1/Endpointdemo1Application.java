package com.bcopstein.endpointdemo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Endpointdemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Endpointdemo1Application.class, args);
	}

}
